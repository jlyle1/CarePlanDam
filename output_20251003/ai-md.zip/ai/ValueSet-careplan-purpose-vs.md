# Care Plan Purpose Value Set - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Care Plan Purpose Value Set**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Narrative Content](#) 
*  [XML](ValueSet-careplan-purpose-vs.xml.md) 
*  [JSON](ValueSet-careplan-purpose-vs.json.md) 
*  [TTL](ValueSet-careplan-purpose-vs.ttl.md) 

## ValueSet: Care Plan Purpose Value Set 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org/dam/ValueSet/careplan-purpose-vs | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:CarePlanPurposeVS |

 
A value set for care plan purposes 

 **References** 

* [CarePlan Logical Model](StructureDefinition-careplan-logical-model.md)

### Logical Definition (CLD)

* Include all codes defined in [`http://hl7.org/dam/CodeSystem/careplan-purpose-cs`](CodeSystem-careplan-purpose-cs.md) version 📦0.1.0

 

### Expansion

Expansion performed internally based on [codesystem Care Plan Purpose v0.1.0 (CodeSystem)](CodeSystem-careplan-purpose-cs.md)

This value set contains 6 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

