# Table of Contents - v0.1.0

* **Table of Contents**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [2 Artifacts Summary](artifacts.md) |
| [2.1 CarePlan Logical Model](StructureDefinition-careplan-logical-model.md) |
| [2.2 CPDPatient](StructureDefinition-CPDPatient.md) |
| [2.3 Care Plan Purpose Value Set](ValueSet-careplan-purpose-vs.md) |
| [2.4 Care Plan Specification Type Value Set](ValueSet-careplan-specification-type-vs.md) |
| [2.5 Care Plan Status Value Set](ValueSet-careplan-status-vs.md) |
| [2.6 Care Plan Purpose](CodeSystem-careplan-purpose-cs.md) |
| [2.7 Care Plan Specification Type](CodeSystem-careplan-specification-type-cs.md) |
| [2.8 Care Plan Status](CodeSystem-careplan-status-cs.md) |
| [2.9 CPDOrganizationExample](Organization-CPDOrganizationExample.md) |
| [2.10 CPDPatientExample](Patient-CPDPatientExample.md) |
| [2.11 CPDPractitionerExample](Practitioner-CPDPractitionerExample.md) |
| [2.12 CPDPractitionerRoleExample](PractitionerRole-CPDPractitionerRoleExample.md) |
| [2.13 Curated Care Plan Example](Binary-CuratedPlanExample.md) |
| [2.14 Static Care Plan Example](Binary-StaticPlanExample.md) |

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

