#  - v0.1.0

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Content](StructureDefinition-careplan-logical-model.md) 
*  [Detailed Descriptions](StructureDefinition-careplan-logical-model-definitions.md) 
*  [Mappings](StructureDefinition-careplan-logical-model-mappings.md) 
*  [Examples](StructureDefinition-careplan-logical-model-examples.md) 
*  [XML](StructureDefinition-careplan-logical-model.profile.xml.md) 
*  [JSON](StructureDefinition-careplan-logical-model.profile.json.md) 
*  [TTL](StructureDefinition-careplan-logical-model.profile.ttl.md) 

## Logical Model: CarePlan - Change History

| |
| :--- |
| Draft as of 2025-10-03 |

Changes in the careplan-logical-model logical model.

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

