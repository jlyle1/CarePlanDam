# Care Plan Specification Type Value Set - Testing - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Care Plan Specification Type Value Set**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Narrative Content](ValueSet-careplan-specification-type-vs.md) 
*  [XML](ValueSet-careplan-specification-type-vs.xml.md) 
*  [JSON](ValueSet-careplan-specification-type-vs.json.md) 
*  [TTL](ValueSet-careplan-specification-type-vs.ttl.md) 

## ValueSet: Care Plan Specification Type Value Set - Testing 

| |
| :--- |
| Draft as of 2025-10-03 |

### Test Plans

**No test plans are currently available for the ValueSet.**

### Test Scripts

**No test scripts are currently available for the ValueSet.**

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

