# Curated Care Plan Example - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Curated Care Plan Example**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Narrative Content](Binary-CuratedPlanExample.md) 
*  [XML](#) 
*  [JSON](Binary-CuratedPlanExample.json.md) 
*  [TTL](Binary-CuratedPlanExample.ttl.md) 

## : Curated Care Plan Example - XML Representation

[Raw xml](Binary-CuratedPlanExample.xml) | [Download](Binary-CuratedPlanExample.xml)

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

