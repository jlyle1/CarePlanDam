# CarePlan Logical Model - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CarePlan Logical Model**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-careplan-logical-model-definitions.md) 
*  [Mappings](StructureDefinition-careplan-logical-model-mappings.md) 
*  [Examples](StructureDefinition-careplan-logical-model-examples.md) 
*  [XML](StructureDefinition-careplan-logical-model.profile.xml.md) 
*  [JSON](StructureDefinition-careplan-logical-model.profile.json.md) 
*  [TTL](StructureDefinition-careplan-logical-model.profile.ttl.md) 

## Logical Model: CarePlan Logical Model 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org/dam/StructureDefinition/careplan-logical-model | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:CarePlan |

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/careplandam|current/StructureDefinition/careplan-logical-model)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(1 nested mandatory element)

**Structures**

This structure refers to these other structures:

* [CPDPatient(http://hl7.org/dam/StructureDefinition/CPDPatient)](StructureDefinition-CPDPatient.md)

 **Key Elements View** 

#### Terminology Bindings

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

 **Snapshot View** 

#### Terminology Bindings

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(1 nested mandatory element)

**Structures**

This structure refers to these other structures:

* [CPDPatient(http://hl7.org/dam/StructureDefinition/CPDPatient)](StructureDefinition-CPDPatient.md)

 

Other representations of profile: [CSV](StructureDefinition-careplan-logical-model.csv), [Excel](StructureDefinition-careplan-logical-model.xlsx) 

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

