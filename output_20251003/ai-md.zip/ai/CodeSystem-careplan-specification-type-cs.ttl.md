# Care Plan Specification Type - TTL Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Care Plan Specification Type**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Narrative Content](CodeSystem-careplan-specification-type-cs.md) 
*  [XML](CodeSystem-careplan-specification-type-cs.xml.md) 
*  [JSON](CodeSystem-careplan-specification-type-cs.json.md) 
*  [TTL](#) 

## : Care Plan Specification Type - TTL Representation

| |
| :--- |
| Draft as of 2025-10-03 |

[Raw ttl](CodeSystem-careplan-specification-type-cs.ttl) | [Download](CodeSystem-careplan-specification-type-cs.ttl)

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

