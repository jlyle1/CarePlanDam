# CPDPatient - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CPDPatient**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-CPDPatient-definitions.md) 
*  [Mappings](StructureDefinition-CPDPatient-mappings.md) 
*  [Examples](StructureDefinition-CPDPatient-examples.md) 
*  [XML](StructureDefinition-CPDPatient.profile.xml.md) 
*  [JSON](StructureDefinition-CPDPatient.profile.json.md) 
*  [TTL](StructureDefinition-CPDPatient.profile.ttl.md) 

## Resource Profile: CPDPatient 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org/dam/StructureDefinition/CPDPatient | *Version*:0.1.0 |
| Draft as of 2025-10-03 | *Computable Name*:CPDPatient |

 
An example profile of the Patient resource. 

**Usages:**

* Refer to this Profile: [CarePlan Logical Model](StructureDefinition-careplan-logical-model.md)
* Examples for this Profile: [Patient/CPDPatientExample](Patient-CPDPatientExample.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/careplandam|current/StructureDefinition/CPDPatient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Key Elements Table](#tabs-key) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 1 element

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Differential View** 

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Patient](http://hl7.org/fhir/R4/patient.html) 

**Summary**

Mandatory: 1 element
 Must-Support: 1 element

 

Other representations of profile: [CSV](StructureDefinition-CPDPatient.csv), [Excel](StructureDefinition-CPDPatient.xlsx), [Schematron](StructureDefinition-CPDPatient.sch) 

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

