# CPDOrganizationExample - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CPDOrganizationExample**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Narrative Content](#) 
*  [XML](Organization-CPDOrganizationExample.xml.md) 
*  [JSON](Organization-CPDOrganizationExample.json.md) 
*  [TTL](Organization-CPDOrganizationExample.ttl.md) 

## Example Organization: CPDOrganizationExample

**name**: The Very Big Corporation of America

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

