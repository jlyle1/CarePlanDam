# CarePlan Logical Model - Mappings - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CarePlan Logical Model**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Content](StructureDefinition-careplan-logical-model.md) 
*  [Detailed Descriptions](StructureDefinition-careplan-logical-model-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-careplan-logical-model-examples.md) 
*  [XML](StructureDefinition-careplan-logical-model.profile.xml.md) 
*  [JSON](StructureDefinition-careplan-logical-model.profile.json.md) 
*  [TTL](StructureDefinition-careplan-logical-model.profile.ttl.md) 

## Logical Model: CarePlan - Mappings

| |
| :--- |
| Draft as of 2025-10-03 |

Mappings for the careplan-logical-model logical model.

No Mappings

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

