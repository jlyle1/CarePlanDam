# CPDPatient - Mappings - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CPDPatient**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Content](StructureDefinition-CPDPatient.md) 
*  [Detailed Descriptions](StructureDefinition-CPDPatient-definitions.md) 
*  [Mappings](#) 
*  [Examples](StructureDefinition-CPDPatient-examples.md) 
*  [XML](StructureDefinition-CPDPatient.profile.xml.md) 
*  [JSON](StructureDefinition-CPDPatient.profile.json.md) 
*  [TTL](StructureDefinition-CPDPatient.profile.ttl.md) 

## Resource Profile: CPDPatient - Mappings

| |
| :--- |
| Draft as of 2025-10-03 |

Mappings for the CPDPatient resource profile.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

