# Curated Care Plan Example - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Curated Care Plan Example**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Narrative Content](#) 

## Example Binary: Curated Care Plan Example

This content is an example of the [CarePlan Logical Model](StructureDefinition-careplan-logical-model.md) Logical Model and is not a FHIR Resource

```

{
  "resourceType": "http://hl7.org/dam/StructureDefinition/careplan-logical-model",
  "planSpecificationType": {
    "coding": [
      {
        "code": "authored-plan",
        "display": "Authored plan"
      }
    ]
  },
  "PlanPurpose": {
    "coding": [
      {
        "code": "home-health",
        "display": "Home health plan"
      }
    ]
  },
  "Author": {
    "reference": "PractitionerRole/CPDPractitionerRoleExample"
  },
  "CreateDate": "2023-10-01T10:00:00Z",
  "LastUpdated": "2023-11-15T10:00:00Z",
  "Status": {
    "coding": [
      {
        "code": "in-progress"
      }
    ]
  },
  "StatusDate": "2023-11-15T10:00:00Z",
  "Name": "Jim's home rehab plan by Dr. Smith",
  "PlanDescription": "Dr. Smith & Jim's home health care plan for post-surgery rehab",
  "Subject": {
    "reference": "Patient/CPDPatientExample"
  }
}

```

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

