# CPDPatient - Definitions - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CPDPatient**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Content](StructureDefinition-CPDPatient.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-CPDPatient-mappings.md) 
*  [Examples](StructureDefinition-CPDPatient-examples.md) 
*  [XML](StructureDefinition-CPDPatient.profile.xml.md) 
*  [JSON](StructureDefinition-CPDPatient.profile.json.md) 
*  [TTL](StructureDefinition-CPDPatient.profile.ttl.md) 

## Resource Profile: CPDPatient - Detailed Descriptions

| |
| :--- |
| Draft as of 2025-10-03 |

Definitions for the CPDPatient resource profile.

*  [Key Elements Table](#tabs-key) 
*  [Differential Elements Table](#tabs-diff) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

