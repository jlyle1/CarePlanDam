# Care Plan Status - XML Representation - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Care Plan Status**

CarePlanDAM - Local Development build (v0.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](http://hl7.org/dam/history.html)

*  [Narrative Content](CodeSystem-careplan-status-cs.md) 
*  [XML](#) 
*  [JSON](CodeSystem-careplan-status-cs.json.md) 
*  [TTL](CodeSystem-careplan-status-cs.ttl.md) 

## : Care Plan Status - XML Representation

| |
| :--- |
| Draft as of 2025-10-03 |

[Raw xml](CodeSystem-careplan-status-cs.xml) | [Download](CodeSystem-careplan-status-cs.xml)

 IG © 2025+ [Patient Care WG](https://www.hl7.org/Special/committees/patientcare). Package careplandam#0.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-03 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md) 

